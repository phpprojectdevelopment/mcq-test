<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MCQ Test</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/form-elements.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="<?php echo base_url() ?>assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url() ?>assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url() ?>assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url() ?>assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="<?php echo base_url() ?>assets/ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                	
                    <div class="row">
                        <div class="col-md-12" style="text-align:right;"><a href="<?php echo base_url('user/logout'); ?>" class="text">Logout</a></div>
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1><strong>mUni Campus</strong> Quiz</h1>
                            <!-- <div class="description">
                            	<p>
	                            	This is a free responsive <strong>"login and register forms"</strong> template made with Bootstrap. 
	                            	Download it on <a href="http://azmind.com" target="_blank"><strong>AZMIND</strong></a>, 
	                            	customize and use it as you like!
                            	</p>
                            </div> -->
                        </div>
                    </div>
                    <br><br>
                    <div class="row text" style="text-align:left;">
                        <?php
                        $questions = $this->mcq_model->getQuestions();
                        foreach($questions as $key=>$val){
                            echo '<form name="examForm">';
                            echo ++$key . ') ' . $val['question'] . "<br>";
                            echo "<input type='hidden' name='question_id[]' value='".$val['id']."'>";
                                $options = $this->mcq_model->getOptions($val['id']);
                                foreach($options as $opt){
                                    echo "<input type='radio' name='answer_id[]' value='".$opt['id']."'>".$opt['option']."<br>";
                                }
                            echo "<br>";
                            echo '</form>';
                        }
                        ?>
                        <input type="submit" value="submit" style="color:black;" onclick="submitExam()">
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Footer -->
        <footer>
        	<div class="container">
        		<div class="row">
        			
        			<div class="col-sm-8 col-sm-offset-2">
        				<div class="footer-border"></div>
        				<p>Made by mUni Campus at <a href="http://muniversity.mobi" target="_blank"><strong>muniversity</strong></a>
        					having a lot of fun. <i class="fa fa-smile-o"></i></p>
        			</div>
        			
        		</div>
        	</div>
        </footer>

        <!-- Javascript -->
        <script src="<?php echo base_url() ?>assets/js/jquery-1.11.1.min.js"></script>
        <script src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/jquery.backstretch.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

        <script>
            function submitExam(){
                var senddata2 = [];
                examForm = document.getElementsByName('examForm');
                formCount = examForm.length;
                for(c=0;c<formCount;c++){
                    question_id = examForm[c].elements['question_id[]'].value;
                    answer_id = examForm[c].elements['answer_id[]'].value;
                    if(answer_id!=''){
                        senddata2.push({"question_id":question_id,"answer_id":answer_id});
                    }
                }
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        res = JSON.parse(this.responseText);
                        if(res.status=='success'){
                           test_score = res.test_score;
                           test_result = res.test_result;
                           window.location.href="<?php echo base_url('mcq_test/loadResultPage?test_score='); ?>"+test_score+"&test_result="+test_result;
                        }else{
                           alert(this.responseText); 
                        }

                    }
                };
                xhttp.open("POST", "<?php echo site_url(); ?>/MCQ_Test/showRecords", true);
                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhttp.send("data="+JSON.stringify(senddata2));
            }
        </script>
    </body>

</html>