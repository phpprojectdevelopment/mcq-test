<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MCQ_Test extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('mcq_model');
	}
	public function displayQuestions(){
		$this->load->view('mcq_test/questions');
	}
	public function showRecords(){
		header("Access-Control-Allow-Origin: *");

		$data = json_decode($this->input->get_post('data'));
		$answerStatus=$totalRightAnswers=$totalWrongAnswers=$totalScore=$examResult=null;
		$totalQuestions = null;		

		foreach($data as $val){
			if($val->question_id!=null){
				$totalQuestions = $totalQuestions+1;
			}
			$answerStatus = $this->mcq_model->getAnswer($val->question_id,$val->answer_id);
			if($answerStatus==1){
				$totalRightAnswers = $totalRightAnswers+1;
			}else if($answerStatus==0){
				$totalWrongAnswers = $totalWrongAnswers+1;
			}
		}

		$totalScore = $this->totalScore($totalRightAnswers,$totalQuestions);
		echo json_encode(array('status'=>'success','message'=>'','test_score'=>$totalScore,'test_result'=>$this->showResult($totalScore)));
	}
	public function totalScore($rightAnswer,$totalQuestions){
		return (($rightAnswer/$totalQuestions)*100);
	}
	public function showResult($totalScore){
		return ($totalScore>=40) ? 'pass':'fail';
	}

	public function loadResultPage(){
		$this->load->view('mcq_test/quiz-result');
	}	
}