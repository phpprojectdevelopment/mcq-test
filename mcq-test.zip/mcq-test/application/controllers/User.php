<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('user_model');
	}
	public function displayForm(){
		$user = $this->session->userdata('logged_in');
		if($user==null){
			$this->loadLoginRegister();
		}
		if($user!=null){
			$this->loadQuiz();
		}
	}
	public function registerUser(){
		$registrationStatus = $this->user_model->register();
		if($registrationStatus==false){
			exit(json_encode(array('status'=>'failed', 'message'=>'Something went wrong, please try again after sometime')));
		}
		echo json_encode(array('status'=>'success', 'message'=>'Registration done, please login'));
	}
	public function checkLogin(){ 
		$loginStatus = $this->user_model->login();
		if($loginStatus==true){
			$this->loadQuiz();
		}
	}
	public function loadQuiz(){
		$this->load->model('mcq_model');
		$this->load->view('mcq_test/quiz');
	}
	public function loadLoginRegister(){
		$this->load->view('users/register-login');
	}
	public function logout(){
		$this->session->sess_destroy();
		$this->loadLoginRegister();
	}
	
}
