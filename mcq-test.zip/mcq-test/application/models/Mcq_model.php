<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mcq_model extends CI_Model{

	public function __construct(){
		$this->load->database();
	}

	public function getQuestions(){
		return $this->db->select("id,question")
			->get("questions")
			->result_array();
	}

	public function getOptions($q_id){
		return $this->db->where(['question_id'=>$q_id])
			->select("id,question_id,option")
			->get("options")
			->result_array();
	}

	public function getAnswer($q_id,$ans_id){
		return $this->db->where(['id'=>$q_id, 'right_option'=>$ans_id])
			->limit(1)
			->get("questions")
			->num_rows();
	}

	/*public function setExamDetails($exam_result,$exam_score,$questions_answers){
		$user_id = 2; // $this->session->userdata('logged_in')['user_id'];
		$data = array(
			'user_id'=>$user_id,
			'exam_result'=>$exam_result,
			'exam_score'=>$exam_score,
			'questions_answers'=>json_encode($questions_answers),
			'created_at'=>date('Y-m-d h:i:sa')
			);
	}*/
}